function effect() {
    var k = document.getElementById("eff1");
    k.style.backgroundColor = "black";
    k.style.color = "darkOrange";
    k.style.animation = "upp-bump 0.2s ease";
}

function effect2() {
    var a = document.getElementById("eff2");
    a.style.backgroundColor = "black";
    a.style.color = "darkOrange";
    a.style.animation = "upp-bump 0.2s ease";
}

function effect3() {
    var v = document.getElementById("eff3");
    v.style.backgroundColor = "black";
    v.style.color = "darkOrange";
    v.style.animation = "upp-bump 0.2s ease";
}

function effect4() {
    var i = document.getElementById("eff4");
    i.style.backgroundColor = "black";
    i.style.color = "darkOrange";
    i.style.animation = "upp-bump 0.2s ease";
}

function effect5() {
    var m = document.getElementById("eff5");
    m.style.backgroundColor = "black";
    m.style.color = "darkOrange";
    m.style.animation = "upp-bump 0.2s ease";
}

function effect6() {
    var g = document.getElementById("eff6");
    g.style.backgroundColor = "black";
    g.style.color = "darkOrange";
    g.style.animation = "upp-bump 0.2s ease";
}